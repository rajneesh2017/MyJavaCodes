package edu.ilstu.itk275.assignment06.rkpande;

import java.util.Random;
import java.util.Scanner;

/**
 * 
 */

/**
 * @author rkpande This class represents the authentication process for user
 *         input as a Password
 */
public class Password {

	// array declaration
	private int[] anArray;

	/**
	 * this method provides user with 0 to 9 and corresponding random number
	 * using 1, 2 and 3
	 * */
	public void getUserScreen() {

		anArray = new int[10];// array with bound 10

		System.out.print("PIN: ");

		// for loop prints array 0 to 9
		for (int i = 0; i < anArray.length; i++) {

			anArray[i] = i;

			System.out.print(anArray[i] + " ");

		}// end of for

		System.out.println();// next line

		Random rand = new Random();// random number object

		System.out.print("NUM: ");

		// for loop prints array of random number using only 1, 2 and 3
		// corresponding to array 0 to 9
		for (int j = 0; j < anArray.length; j++) {

			int num = rand.nextInt(3) + 1;

			anArray[j] = num;

			System.out.print(anArray[j] + " ");

		}// end of second for

	}// end of getUserScreen method

	/**
	 * this method gets user input and matches with actual PIN
	 */
	public void getUserInput() {

		Scanner input = new Scanner(System.in);// Scanner object

		System.out
		.println("\n\nEnter random numbers using \"NUM\" that correspond to your PIN instead of their actual PIN and without using space:");

		int userInput = input.nextInt();// user input

		/*
		 * this gives actual pin which can be set by anArray index. Here anArray
		 * index 1, 2, 3, 4, 5 has been set for password 12345. It can be
		 * changed to any number between 0 to 9
		 */
		int actualPIN = anArray[1] * 10000 + anArray[2] * 1000 + anArray[3]
				* 100 + anArray[4] * 10 + anArray[5];

		/*
		 * condition for user input which is random number which should be
		 * corresponding to actual PIN to match
		 */
		if (actualPIN == userInput)

			System.out.println("PIN matched");

		else

			System.out.println("PIN Not Matched");

	}// end of getuserInput method

}// end of class
