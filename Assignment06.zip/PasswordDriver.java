/**
 * 
 */
package edu.ilstu.itk275.assignment06.rkpande;

/**
 * @author rkpande this is a driver class contains main method
 */
public class PasswordDriver {

	/**
	 * @param args
	 *            main method starts here
	 */
	public static void main(String[] args) {

		// Object created for class Password
		Password obj = new Password();

		// calling method
		obj.getUserScreen();

		obj.getUserInput();

	}// end of main

}// end of class
