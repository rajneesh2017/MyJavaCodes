/**
 * 
 */
package edi.ilstu.itk275.assignment10.rkpande;

/**
 * @author rkpande This class represents the common attributes for two files
 */
public class NameFile {

	// variable declaration
	private String name;
	private int nbrOfRegisteredNames;

	// default constructor
	public NameFile() {
	}

	// paramatrized constructor
	public NameFile(String lineFromFile) {

		String[] fields = lineFromFile.split(" ");

		name = fields[0];

		nbrOfRegisteredNames = Integer.parseInt(fields[1]);

	}// end of Parameterized constructor

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the nbrOfRegisteredNames
	 */
	public int getNbrOfRegisteredNames() {
		return nbrOfRegisteredNames;
	}

	/**
	 * @param nbrOfRegisteredNames
	 *            the nbrOfRegisteredNames to set
	 */
	public void setNbrOfRegisteredNames(int nbrOfRegisteredNames) {
		this.nbrOfRegisteredNames = nbrOfRegisteredNames;
	}

}// end of class
