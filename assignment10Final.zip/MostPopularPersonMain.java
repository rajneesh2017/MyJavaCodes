/**
 * 
 */
package edi.ilstu.itk275.assignment10.rkpande;

import java.io.IOException;

/**
 * @author rkpande This class contains main method
 */
public class MostPopularPersonMain {

	// file location
	private static final String BOY_NAME = ".\\boynames.txt";
	private static final String GIRL_NAME = ".\\girlnames.txt";

	/**
	 * @param args
	 *            main method starts here
	 */
	public static void main(String[] args) {

		MostPopularPerson table = new MostPopularPerson();

		try {

			// calling method
			table.loadTableFromFile(BOY_NAME);

			table.loadTableFromFile(GIRL_NAME);

			// prints information name given
			table.getNameFromFile();

		}// end of try

		// catch IOException
		catch (IOException ioe) {

			ioe.printStackTrace();

		}// end of catch		

	}// end of main

}// end of class
