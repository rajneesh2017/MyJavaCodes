/**
 * 
 */
package edi.ilstu.itk275.assignment10.rkpande;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author rkpande This class searches the name given by user and prints its
 *         popularity
 */
public class MostPopularPerson {

	int nbrOfLine = 1;
	// ArrayList declaration
	private ArrayList<NameFile> elementTable;

	// default constructor
	public MostPopularPerson() {

		// ArrayList initialization
		elementTable = new ArrayList<NameFile>();

	}

	// Method to match Name given by user and print popularity
	public NameFile getNameFromFile() throws NullPointerException {

		// Scanner class object
		Scanner keyboard = new Scanner(System.in);

		NameFile retVal = null;

		System.out.println("Enter the name to find its popularity");

		String searchName = keyboard.next();// keyboard input

		// correct the name format given by user to match with the names in the
		// file
		String changeNameFormat = searchName.substring(0, 1).toUpperCase()
				+ searchName.substring(1).toLowerCase();

		boolean noMatchBoy = true;

		boolean noMatchGirl = true;

		// loop to match name
		for (NameFile e : elementTable) {

			nbrOfLine++;

			// condition to get name matched
			if (changeNameFormat.equals(e.getName())) {

				retVal = e;

				if (nbrOfLine < 1000) {

					System.out.println(retVal.getName() + " is ranked "
							+ nbrOfLine + " in popularity among boys with "
							+ e.getNbrOfRegisteredNames()
							+ " boys receiving the name");

					noMatchBoy = false;
				} else {
					int newNbrOfLine = nbrOfLine - 999;
					System.out.println(retVal.getName() + " is ranked "
							+ newNbrOfLine + " in popularity among girls with "
							+ e.getNbrOfRegisteredNames()
							+ " girls receiving the name");
					noMatchGirl = false;
				}

			}// end of first if

		}// end of for

		if (noMatchBoy == true && noMatchGirl == true) {

			System.out.println(changeNameFormat
					+ " is not ranked among top 1000 boy names");

			System.out.println(changeNameFormat
					+ " is not ranked among top 1000 girl names");

		}

		else {

			if (noMatchBoy) {

				System.out.println(changeNameFormat
						+ " is not ranked among top 1000 boy names");

			}

			else {

				if (noMatchGirl) {
					System.out.println(changeNameFormat
							+ " is not ranked among top 1000 girl names");

				}

			}

		}

		return retVal;

	}// end of method getNameFromFile

	// method to load file
	public void loadTableFromFile(String fileName) throws IOException {

		// File object
		File inputFile = new File(fileName);

		// BufferedReader object
		BufferedReader br = new BufferedReader(new InputStreamReader(
				new FileInputStream(inputFile)));

		String anElementLine = br.readLine();

		while ((anElementLine = br.readLine()) != null) {

			NameFile e = new NameFile(anElementLine);

			elementTable.add(e);// add element

		}

	}// end of method loadTableFromFile

}// end of class
