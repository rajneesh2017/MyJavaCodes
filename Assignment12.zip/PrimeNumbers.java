/**
 * 
 */
package edu.ilstu.itk275.assignment12.rkpande;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author rkpande this class generates prime numbers using the Sieve of
 *         Erastothenes algorithm.
 */
public class PrimeNumbers {

	// creating an object for ArrayList
	ArrayList<Integer> arr = new ArrayList<Integer>();

	// this method adds numbers to ArrayList object
	public void getNumbers() {

		for (int num = 2; num < 101; num++) {

			arr.add(num);// adds numbers to ArrayList

		}

	}

	// this method gets the prime number
	public void getPrimeNumbers() {

		// this loop runs to remove elements which are not prime
		for (int index = 0; index < arr.size(); index++) {

			// Iterator to iterate through ArrayList
			Iterator<Integer> itr = arr.iterator();

			while (itr.hasNext()) {

				// parsing object to Integer
				int element = (Integer) itr.next();

				// condition to get the prime number
				if (element != arr.get(index) && element % arr.get(index) == 0) {

					itr.remove();// remove element

				}// end of if

			}// end of 1st while

		}// end of 1st for loop

		System.out.println("List of Prime Numbers between 2 to 100: ");

		// this loop prints updated ArrayList with elements which are Prime
		// Numbers
		for (int index = 0; index < arr.size(); index++) {

			System.out.print(arr.get(index) + " ");

		}

	}// end of method getPrimeNumbers

}// end of class
