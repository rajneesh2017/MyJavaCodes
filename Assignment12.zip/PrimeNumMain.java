/**
 * 
 */
package edu.ilstu.itk275.assignment12.rkpande;

/**
 * @author rkpande This class contains main method and invokes method in
 *         PrimeNumbers class
 */
public class PrimeNumMain {

	/**
	 * @param args
	 *            main methos starts here
	 */
	public static void main(String[] args) {

		// creating object
		PrimeNumbers obj = new PrimeNumbers();

		// calling method
		obj.getNumbers();

		obj.getPrimeNumbers();

	}// end of main method

}// end of class
